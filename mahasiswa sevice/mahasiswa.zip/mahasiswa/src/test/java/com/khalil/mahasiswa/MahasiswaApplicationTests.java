package com.khalil.mahasiswa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MahasiswaApplicationTests {

	@Test
	void contextLoads() {
	}

}
